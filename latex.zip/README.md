Compiler: XeLaTeX. Main file: article.tex. Run twice; no BibTeX required.
